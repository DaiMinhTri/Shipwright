﻿## 1.1.0
- Updated for Valheim 1.0.12
- Replaced pre-compiled ServerSync with embedded version
- Added missing hammerbucketbundle asset
- Fixed API breaking changes
